document.addEventListener("DOMContentLoaded", () => {
    const addBtn = document.getElementById("add");
    const moviesSection = document.querySelector(".movies");
    let originalMoviesHTML = moviesSection.innerHTML;
  
    // Store reference to the movie-list container
    let movieList = document.querySelector(".movie-list");
  
    // Show Add Movie Form
    addBtn.addEventListener("click", () => {
      moviesSection.innerHTML = `
        <h2>Add a New Movie</h2>
        <form id="addMovieForm">
          <label for="movieName">Movie Name</label>
          <input type="text" id="movieName" name="movieName" required>
  
          <label for="screen">Screen</label>
          <input type="text" id="screen" name="screen" required>
  
          <label for="language">Language</label>
          <input type="text" id="language" name="language" required>
  
          <label for="duration">Duration (in minutes)</label>
          <input type="number" id="duration" name="duration" required>
  
          <label for="category">Category</label>
          <input type="text" id="category" name="category" required>
  
          <label for="certificate">Certificate</label>
          <select id="certificate" name="certificate" required>
            <option value="">--Select--</option>
            <option value="U">U</option>
            <option value="U/A">U/A</option>
            <option value="A">A</option>
          </select>
  
          <label for="releaseDate">Releasing Date</label>
          <input type="date" id="releaseDate" name="releaseDate" required>
  
          <label for="posterUrl">Poster URL</label>
          <input type="url" id="posterUrl" placeholder="Paste Poster URL">
  
          <label for="bannerUrl">Banner URL</label>
          <input type="url" id="bannerUrl" placeholder="Paste Banner URL">
  
          <button type="submit" class="submit">Submit</button>
          <button type="button" id="backBtn" class="return" style="margin-left: 10px;">Back</button>
        </form>
      `;
  
      // Back button to go back to original movie list
      document.getElementById("backBtn").addEventListener("click", () => {
        moviesSection.innerHTML = originalMoviesHTML;
        rebindMovieClickEvents();
      });
  
      // Handle movie form submission
      document.getElementById("addMovieForm").addEventListener("submit", function (e) {
        e.preventDefault();
  
        const movie = {
          name: document.getElementById("movieName").value,
          screen: document.getElementById("screen").value,
          language: document.getElementById("language").value,
          duration: document.getElementById("duration").value,
          category: document.getElementById("category").value,
          certificate: document.getElementById("certificate").value,
          releaseDate: document.getElementById("releaseDate").value,
          posterUrl: document.getElementById("posterUrl").value || "/images/default-poster.jpg",
          bannerUrl: document.getElementById("bannerUrl").value || ""
        };
  
        // Go back to movie list
        moviesSection.innerHTML = originalMoviesHTML;
  
        // Append new movie card
        const newCard = document.createElement("div");
        newCard.classList.add("movie");
        newCard.setAttribute("data-title", movie.name);
        newCard.setAttribute("data-poster", movie.posterUrl);
        newCard.innerHTML = `
          <img src="${movie.posterUrl}" alt="${movie.name}">
          <p>${movie.name}</p>
        `;
        document.querySelector(".movie-list").appendChild(newCard);
  
        rebindMovieClickEvents();
      });
    });
  
    // Function to bind click event to movie cards
    function rebindMovieClickEvents() {
      const updatedMovieList = document.querySelector(".movie-list");
  
      updatedMovieList.querySelectorAll(".movie").forEach(movieCard => {
        movieCard.addEventListener("click", function () {
          const title = movieCard.getAttribute("data-title") || "Unknown Movie";
          const posterSrc = movieCard.querySelector("img").src;
  
          moviesSection.innerHTML = `
            <div class="movie-container">
              <img src="${posterSrc}" alt="${title} Poster" class="movie-poster">
              <div class="movie-details">
                <h1>${title}</h1>
                <p class="rating">⭐ 8.1/10 (95.1K Votes)</p>
                <button class="rate-btn">Rate now</button>
                <p><strong>2D, IMAX 2D</strong> | Malayalam, Hindi, Kannada, Tamil, Telugu</p>
                <p>2h 59m • Action, Crime, Thriller • UA16+ • 27 Mar, 2025</p>
                <button class="Edit">Edit</button> 
                <button class="Edit">Delete</button>
                <button class="return" type="button" id="backBtn">Back</button>
              </div>
            </div>
          `;
  
          document.getElementById("backBtn").addEventListener("click", () => {
            moviesSection.innerHTML = originalMoviesHTML;
            rebindMovieClickEvents();
          });
        });
      });
    }
  
    // Initial binding
    rebindMovieClickEvents();
  });
  