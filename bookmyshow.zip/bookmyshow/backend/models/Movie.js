import mongoose from "mongoose";

const movieSchema = new mongoose.Schema({
  name: String,
  screen: String,
  language: String,
  duration: String,
  category: String,
  certificate: String,
  releaseDate: String,
  posterUrl: String,
  bannerUrl: String,
});

const Movie = mongoose.model("Movie", movieSchema);

export default Movie;
