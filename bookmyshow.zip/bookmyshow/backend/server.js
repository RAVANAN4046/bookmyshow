
import express from "express";
import path from "path";
import url from "url";
import connection from "./connection.js";
import Movie from "./models/Movie.js";

const app = express();

app.use(express.json({ limit: "100mb" }));

const __dirname = path.dirname(url.fileURLToPath(import.meta.url));

app.use(express.static(path.join(__dirname, "public")));


app.post("/api/movies", async (req, res) => {
  try {
    const movie = new Movie(req.body);
    await movie.save();
    res.status(201).send(movie);
  } catch (err) {
    res.status(500).send({ error: err.message });
  }
});


app.get("/api/movies", async (req, res) => {
  try {
    const movies = await Movie.find();
    res.status(200).send(movies);
  } catch (err) {
    res.status(500).send({ error: err.message });
  }
});


app.put("/api/movies/:id", async (req, res) => {
  try {
    await Movie.findByIdAndUpdate(id, updates);
    res.status(200).send(updated);
  } catch (err) {
    res.status(500).send({ error: err.message });
  }
});


app.delete("/api/movies/:id", async (req, res) => {
  try {
    await Movie.findByIdAndDelete(id);
    res.status(200).send(deleted);
  } catch (err) {
    res.status(500).send({ error: err.message });
  }
});


app.get("/", (req, res) => {
  res.sendFile(path.resolve(__dirname, "public", "index.html"));
});


connection()
  .then(() => {
    app.listen(5050, () => {
      console.log(`Server running on http://localhost:5050`);
    });
  })
  .catch((err) => {
    console.error(" DB Connection Error:", err);
  });
