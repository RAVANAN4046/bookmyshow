document.addEventListener("DOMContentLoaded", () => {
  const addBtn = document.getElementById("add");
  const moviesSection = document.querySelector(".movies");
  const originalMoviesHTML = moviesSection.innerHTML;

  addBtn.addEventListener("click", () => {
    moviesSection.innerHTML = `
      <h2>Add a New Movie</h2>
      <form id="addMovieForm">
        <label for="movieName">Movie Name</label>
        <input type="text" id="movieName" required>

        <label for="screen">Screen</label>
        <input type="text" id="screen" required>

        <label for="language">Language</label>
        <input type="text" id="language" required>

        <label for="duration">Duration (in minutes)</label>
        <input type="text" id="duration" required>

        <label for="category">Category</label>
        <input type="text" id="category" required>

        <label for="certificate">Certificate</label>
        <select id="certificate" required>
          <option value="">--Select--</option>
          <option value="U">U</option>
          <option value="U/A">U/A</option>
          <option value="A">A</option>
        </select>

        <label for="releaseDate">Releasing Date</label>
        <input type="date" id="releaseDate" required>

        <label for="posterFile">Upload Poster Image</label>
        <input type="file" id="posterFile" accept="image/*" required>

        <label for="bannerFile">Upload Banner Image</label>
        <input type="file" id="bannerFile" accept="image/*">

        <button type="submit" class="submit">Submit</button>
        <button type="button" id="backBtn" class="return">Back</button>
      </form>
    `;



    document.getElementById("backBtn").addEventListener("click", () => {
      moviesSection.innerHTML = originalMoviesHTML;
      rebindMovieClickEvents();
      fetch("/api/movies")
  .then(res => res.json())
  .then(data => {
    const movieList = document.querySelector(".movie-list");
    movieList.innerHTML = ""

    data.forEach((movie) => {
      const card = document.createElement("div");
      card.classList.add("movie");

      Object.entries(movie).forEach(([key, value]) => {
        card.setAttribute(`data-${key.toLowerCase()}`, value);
      });

      card.innerHTML = `
        <img src="${movie.posterUrl}" alt="${movie.name}" />
        <p>${movie.name}</p>
      `;

      movieList.appendChild(card);
    });

    rebindMovieClickEvents(); 
  })
  .catch(err => {
    console.error("Error loading movies:", err);
    alert("Failed to load movies.");
  });

    });



    document.getElementById("addMovieForm").addEventListener("submit", function (e) {
      e.preventDefault();

      moviesSection.innerHTML = originalMoviesHTML;


      const posterFile = document.getElementById("posterFile").files[0];
      const bannerFile = document.getElementById("bannerFile").files[0];

      if (!posterFile) {
        alert("Poster is required.");
        return;
      }

      const reader = new FileReader();

reader.onload = () => {
  const posterBase64 = reader.result;

  const movie = {
    name: document.getElementById("movieName").value,
    screen: document.getElementById("screen").value,
    language: document.getElementById("language").value,
    duration: document.getElementById("duration").value,
    category: document.getElementById("category").value,
    certificate: document.getElementById("certificate").value,
    releaseDate: document.getElementById("releaseDate").value,
    posterUrl: posterBase64,
    bannerUrl: "", 
  };

  if (bannerFile) {
    const bannerReader = new FileReader();
    bannerReader.onload = () => {
      movie.bannerUrl = bannerReader.result;

      sendMovie(movie);
    };
    bannerReader.readAsDataURL(bannerFile);
  } else {
    sendMovie(movie); 
  } 
};

reader.readAsDataURL(posterFile);

function sendMovie(movie) {
  fetch("/api/movies", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify(movie),
  })
    .then((res) => res.json())
    .then((data) => {
      console.log("Movie saved:", data);
      alert("Movie added successfully!");
      location.reload(); 
      moviesSection.innerHTML = originalMoviesHTML;

      const movieList = document.querySelector(".movie-list");

      const newCard = document.createElement("div");
      newCard.classList.add("movie");
      Object.entries(movie).forEach(([key, value]) => {
        newCard.setAttribute(`data-${key}`, value);
      });

      newCard.innerHTML = `
        <img src="${movie.posterUrl}" alt="${movie.name}" />
        <p>${movie.name}</p>
      `;

      movieList.appendChild(newCard);

      rebindMovieClickEvents();
    
    })
    .catch((err) => {
      console.error("Error saving movie:", err);
      alert("Failed to save movie.");
    });
}

      

      moviesSection.innerHTML = originalMoviesHTML;
      const movieList = document.querySelector(".movie-list");

      const newCard = document.createElement("div");
      newCard.classList.add("movie");
      Object.entries(movie).forEach(([key, value]) => {
        newCard.setAttribute(`data-${key}`, value);
      });

      newCard.innerHTML = `
        <img src="${movie.posterUrl}" alt="${movie.name}" />
        <p>${movie.name}</p>
      `;

      movieList.appendChild(newCard);
      rebindMovieClickEvents();
    });
  });

  function rebindMovieClickEvents() {
    const movieCards = document.querySelectorAll(".movie");

    movieCards.forEach(movieCard => {
      movieCard.addEventListener("click", () => {
        const title = movieCard.getAttribute("data-name");
        const posterSrc = movieCard.getAttribute("data-posterurl");
        const screen = movieCard.getAttribute("data-screen");
        const language = movieCard.getAttribute("data-language");
        const duration = movieCard.getAttribute("data-duration");
        const category = movieCard.getAttribute("data-category");
        const certificate = movieCard.getAttribute("data-certificate");
        const releaseDate = movieCard.getAttribute("data-releaseDate");
        const bannerUrl = movieCard.getAttribute("data-bannerurl");

        moviesSection.innerHTML = `
          <div class="movie-container">
            <img src="${posterSrc}" alt="${title} Poster" class="movie-poster">
            <div class="movie-details">
              <h1 style="color: white;">${title}</h1>
              <p style="background-color: white;"><strong>${screen}</strong> | ${language}</p>
              <p style="color: white;">${duration} • ${category} • ${certificate} • ${new Date(releaseDate).toDateString()}</p>
              <button id="Edit" class="edit-movie">Edit</button>
              <button class="Delete" id="deleteMovie">Delete</button>
              <button id="backBtn" class="return">Back</button>
            </div>
          </div>
        `;

        document.getElementById("backBtn").addEventListener("click", () => {
          moviesSection.innerHTML = originalMoviesHTML;
          rebindMovieClickEvents();
        });

        document.querySelector(".edit-movie").addEventListener("click", () => {
          moviesSection.innerHTML = `
            <h2>Edit Movie</h2>
            <form id="editMovieForm">
              <label for="movieName">Movie Name</label>
              <input type="text" id="movieName" value="${title}" required>

              <label for="screen">Screen</label>
              <input type="text" id="screen" value="${screen}" required>

              <label for="language">Language</label>
              <input type="text" id="language" value="${language}" required>

              <label for="duration">Duration (in minutes)</label>
              <input type="text" id="duration" value="${duration}" required>

              <label for="category">Category</label>
              <input type="text" id="category" value="${category}" required>

              <label for="certificate">Certificate</label>
              <select id="certificate" required>
                <option value="">--Select--</option>
                <option value="U" ${certificate === "U" ? "selected" : ""}>U</option>
                <option value="U/A" ${certificate === "U/A" ? "selected" : ""}>U/A</option>
                <option value="A" ${certificate === "A" ? "selected" : ""}>A</option>
              </select>

              <label for="releaseDate">Releasing Date</label>
              <input type="date" id="releaseDate" value="${releaseDate}" required>

              <label for="posterFile">Upload Poster Image</label>
              <input type="file" id="posterFile" accept="image/*">

              <label for="bannerFile">Upload Banner Image</label>
              <input type="file" id="bannerFile" accept="image/*">

              <button type="submit" class="submit">Update</button>
              <button type="button" id="backBtn" class="return">Back</button>
            </form>
          `;

          document.getElementById("backBtn").addEventListener("click", () => {
            moviesSection.innerHTML = originalMoviesHTML;
            rebindMovieClickEvents();
          });

          
          

          document.getElementById("editMovieForm").addEventListener("submit", function (e) {
            e.preventDefault();
          
            const posterInput = document.getElementById("posterFile");
            const bannerInput = document.getElementById("bannerFile");
            const posterFile = posterInput.files[0];
            const bannerFile = bannerInput.files[0];
          
            const updatedMovie = {
              name: document.getElementById("movieName").value,
              screen: document.getElementById("screen").value,
              language: document.getElementById("language").value,
              duration: document.getElementById("duration").value,
              category: document.getElementById("category").value,
              certificate: document.getElementById("certificate").value,
              releaseDate: document.getElementById("releaseDate").value,
              posterUrl: posterSrc,
              bannerUrl: bannerUrl,
            };
          
            const readFileAsBase64 = (file) =>
              new Promise((resolve, reject) => {
                const reader = new FileReader();
                reader.onload = () => resolve(reader.result);
                reader.onerror = reject;
                reader.readAsDataURL(file);
              });
          
            const promises = [];
          
            if (posterFile) {
              promises.push(readFileAsBase64(posterFile).then(res => updatedMovie.posterUrl = res));
            }
          
            if (bannerFile) {
              promises.push(readFileAsBase64(bannerFile).then(res => updatedMovie.bannerUrl = res));
            }
          
            Promise.all(promises).then(() => {
              fetch("/api/movies/update", {
                method: "PUT",
                headers: {
                  "Content-Type": "application/json",
                },
                body: JSON.stringify(updatedMovie),
              })
              .then(res => res.json())
              .then(() => {
                alert("Movie updated!");
                location.reload();
              })
              .catch(err => {
                console.error("Error updating:", err);
                alert("Failed to update.");
              });
            });
          });
          
        });

        
        document.getElementById("deleteMovie").addEventListener("click", () => {
          if (confirm(`Are you sure you want to delete "${title}"?`)) {
            movieCard.remove();
            moviesSection.innerHTML = originalMoviesHTML;
            rebindMovieClickEvents();
          }
        });
      });
    });
  }

  rebindMovieClickEvents();
});